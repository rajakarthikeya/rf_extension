var greeting = "hola, ";
  var button = document.getElementById("left_arrow");
  button.addEventListener("click", function() {
    alert(greeting + ".");
  }, false);