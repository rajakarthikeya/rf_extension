document.getElementById("left_arrow").addEventListener("click", funcForLeft);

function funcForLeft() {
		chrome.tabs.query({
				currentWindow: true,
				active: true
			}, function (tabs) {
				navigateToNewUrl(tabs[0].url, false);
		});
}

function checkStatusOfUrl(url) {
	var request = new XMLHttpRequest;
	request.open("GET", url, false);
	request.send();
	if (request.status == 200) {
		return true;
	}
    alert('Bad request');
	return false;
}

function navigateToNewUrl(urlOfCurrentTab, isItIncrement){
    var valueToBeAddOrSub = 0;
   
    var valueProvided = document.getElementById("shift_value").value;
    if(""===valueProvided){
        valueToBeAddOrSub = 1;
    }else{
        valueToBeAddOrSub = valueProvided;
    }
    
    if(!isItIncrement){
            valueToBeAddOrSub = 0 - valueToBeAddOrSub;
       }
    
    
    var curretUrl = urlOfCurrentTab;
				if (curretUrl.includes("console")) {
					var console_match = curretUrl.match(/(\d+)\/console/g);
					var match_string = String(console_match);
					var temp = match_string.match(/(\d+)/g);
					var updated = match_string.replace(temp, parseInt(temp) + parseInt(valueToBeAddOrSub));
					var myNewUrl = curretUrl.replace(match_string, updated);
                    if (checkStatusOfUrl(myNewUrl)) {
						chrome.tabs.update({
							url: myNewUrl
						});
					}
                    else{
                        alert('There is an issue in navigating to new console');
                    }
				} else if (curretUrl.includes("selenium-screenshot")) {
                    var console_match = curretUrl.match(/robot\/report\/selenium-screenshot-(\d+)\.png/g);
                    var match_string = String(console_match);
					var temp = match_string.match(/(\d+)/g);
                    var updated = match_string.replace(temp, parseInt(temp) + parseInt(valueToBeAddOrSub));
                    var myNewUrl = curretUrl.replace(match_string, updated);
                    if (checkStatusOfUrl(myNewUrl)) {
						chrome.tabs.update({
							url: myNewUrl
						});
					}
                    else{
                        alert('There is an issue in navigating to new screenshot');
                    }
				}
}

document.addEventListener('DOMContentLoaded', function () {
	var link = document.getElementById('right_arrow');

	link.addEventListener('click', function () {
		chrome.tabs.query({
				currentWindow: true,
				active: true
			}, function (tabs) {
				navigateToNewUrl(tabs[0].url, true);
		});
	});
});